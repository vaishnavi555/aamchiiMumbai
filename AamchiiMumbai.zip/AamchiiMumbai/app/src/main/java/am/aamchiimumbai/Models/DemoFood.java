package am.aamchiimumbai.Models;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.firebase.firestore.GeoPoint;
public class DemoFood implements Parcelable {

    private String foodName;
    private String foodAddress;
    private String foodDistance;
    private String foodNear;
    private String foodPhoneNumber;
    private String foodRatings;
    private String foodTimings;
    private String foodType;
    private GeoPoint foodGeo;

    public DemoFood(String foodName, String foodAddress, String foodDistance, String foodNear, String foodPhoneNumber, String foodRatings, String foodTimings, String foodType) {
    }

    public DemoFood(String foodName, String foodAddress, String foodDistance, String foodNear, String foodPhoneNumber, String foodRatings, String foodTimings, String foodType, GeoPoint foodGeo) {
        this.foodName = foodName;
        this.foodAddress = foodAddress;
        this.foodDistance = foodDistance;
        this.foodNear = foodNear;
        this.foodPhoneNumber = foodPhoneNumber;
        this.foodRatings = foodRatings;
        this.foodTimings = foodTimings;
        this.foodType = foodType;
        this.foodGeo = foodGeo;

    }

    public String getFoodName() {
        return foodName;
    }

    public String getFoodAddress() {
        return foodAddress;
    }

    public String getFoodDistance() {
        return foodDistance;
    }

    public String getFoodNear() {
        return foodNear;
    }

    public String getFoodPhoneNumber() {
        return foodPhoneNumber;
    }

    public String getFoodRatings() {
        return foodRatings;
    }

    public String getFoodTimings() {
        return foodTimings;
    }

    public String getFoodType() {
        return foodType;
    }

    public GeoPoint getFoodGeo(){return  foodGeo;}


    protected DemoFood(Parcel in) {
        foodName = in.readString();
        foodAddress = in.readString();
        foodDistance = in.readString();
        foodNear = in.readString();
        foodPhoneNumber = in.readString();
        foodRatings = in.readString();
        foodTimings = in.readString();
        foodType = in.readString();
        foodGeo = (GeoPoint) in.readValue(GeoPoint.class.getClassLoader());
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(foodName);
        dest.writeString(foodAddress);
        dest.writeString(foodDistance);
        dest.writeString(foodNear);
        dest.writeString(foodPhoneNumber);
        dest.writeString(foodRatings);
        dest.writeString(foodTimings);
        dest.writeString(foodType);
        dest.writeValue(foodGeo);
    }

    @SuppressWarnings("unused")
    public static final Parcelable.Creator<DemoFood> CREATOR = new Parcelable.Creator<DemoFood>() {
        @Override
        public DemoFood createFromParcel(Parcel in) {
            return new DemoFood(in);
        }

        @Override
        public DemoFood[] newArray(int size) {
            return new DemoFood[size];
        }
    };
}