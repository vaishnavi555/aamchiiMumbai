package am.aamchiimumbai.Models;


import android.os.Parcel;
import android.os.Parcelable;

import com.google.firebase.firestore.GeoPoint;

public class DemoPlace implements Parcelable{


//    private  int id;
    private GeoPoint placeGeo;
    private String placeName;
    private String busStop ;//do min ruk ok
    private String placeCabs;
    private String placeBestTime;
    private String placeEntryFees;
    private String placeHistory;
    private String placeHowFar;
    private String placeHowToReach;
    private String placeHighlights;
    private String placeInfo;
    private String placeLocation;
    private String placeNearbyPlaces;
    private String placeReadMore;
    private String imageUrl;
    public DemoPlace(){

    }


    public DemoPlace(String placeName, String busStop, String placeCabs, String placeBestTime, String placeEntryFees, String placeHistory, String placeHowFar, String placeHowToReach, String placeHighlights, String placeInfo, String placeLocation, String placeNearbyPlaces, String placeReadMore, String imageUrl, GeoPoint placeGeo) {
        this.placeName = placeName;
        this.busStop = busStop;
        this.placeCabs = placeCabs;
        this.placeBestTime = placeBestTime;
        this.placeEntryFees = placeEntryFees;
        this.placeHistory = placeHistory;
        this.placeHowFar = placeHowFar;
        this.placeHowToReach = placeHowToReach;
        this.placeHighlights = placeHighlights;
        this.placeInfo = placeInfo;
        this.placeLocation = placeLocation;
        this.placeNearbyPlaces = placeNearbyPlaces;
        this.placeReadMore = placeReadMore;
        this.imageUrl = imageUrl;
        this.placeGeo=placeGeo;
    }

//    public DemoPlace(String name, String busStop, String placeCabs, String placeBestTime, String entryFees, String placeHistory, String placeHowFar, String placeHowToReach, String placeHighlights, String placeInfo, String placeLocation, String placeNearbyPlaces, String placeReadMore) {
//        this.placeName = name;
//        this.busStop = busStop;
//        this.placeCabs = placeCabs;
//        this.placeBestTime = placeBestTime;
//        this.placeEntryFees = entryFees;
//        this.placeHistory = placeHistory;
//        this.placeHowFar = placeHowFar;
//        this.placeHowToReach = placeHowToReach;
//        this.placeHighlights= placeHighlights;
//        this.placeInfo=placeInfo;
//        this.placeLocation=placeLocation;
//        this.placeNearbyPlaces=placeNearbyPlaces;
//        this.placeReadMore=placeReadMore;
//    }


    public String getImageUrl() {
        return imageUrl;
    }

    public String getPlaceName() {
        return placeName;
    }

    public String getBusStop() {
        return busStop;
    }

    public String getPlaceCabs() {
        return placeCabs;
    }

    public String getPlaceBestTime() {
        return placeBestTime;
    }

    public String getPlaceEntryFees() {
        return placeEntryFees;
    }

    public String getPlaceHistory() {
        return placeHistory;
    }

    public String getPlaceHowFar() {
        return placeHowFar;
    }

    public String getPlaceHighlights() { return placeHighlights; }

    public String getPlaceInfo() { return placeInfo; }

    public String getPlaceLocation() { return placeLocation; }

    public String getPlaceNearbyPlaces() { return placeNearbyPlaces; }

    public String getPlaceReadMore() { return placeReadMore; }

    public String getPlaceHowToReach() {
        return placeHowToReach;
    }

    public GeoPoint getPlaceGeo(){return  placeGeo;}

    protected DemoPlace(Parcel in ){
        placeName= in.readString();
        placeReadMore= in.readString();
        placeNearbyPlaces=in.readString();
        placeLocation=in.readString();
        placeInfo=in.readString();
        placeHighlights=in.readString();
        placeBestTime=in.readString();
        placeCabs=in.readString();
        placeEntryFees=in.readString();
        placeHistory=in.readString();
        placeHowFar=in.readString();
        placeHowToReach=in.readString();
        placeGeo= (GeoPoint)in.readValue(GeoPoint.class.getClassLoader());
    }


    @Override
    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags){
        dest.writeString(placeBestTime);
        dest.writeString(placeCabs);
        dest.writeString(placeEntryFees);
        dest.writeString(placeHighlights);
        dest.writeString(placeHistory);
        dest.writeString(placeHowFar);
        dest.writeString(placeHowToReach);
        dest.writeString(placeInfo);
        dest.writeString(placeLocation);
        dest.writeString(placeName);
        dest.writeString(placeNearbyPlaces);
        dest.writeString(placeReadMore);
        dest.writeValue(placeGeo);

    }

    public static final Parcelable.Creator<DemoPlace>CREATOR=new Parcelable.Creator<DemoPlace>(){


        @Override
        public DemoPlace createFromParcel(Parcel in) {
            return new DemoPlace(in);
        }

        public DemoPlace[]newArray(int size){
            return new DemoPlace[size];

        }
    };



}
